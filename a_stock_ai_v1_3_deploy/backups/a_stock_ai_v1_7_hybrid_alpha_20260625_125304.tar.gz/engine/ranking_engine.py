from __future__ import annotations

from typing import Any

from app.config import settings
from data.tushare_client import Quote
from engine.quality_engine import evaluate_quality
from engine.tradability_engine import evaluate_tradability
from learning.strategy_params import param_float, param_int


def build_recommendation_bundle(
    state: dict[str, Any],
    leader: dict[str, Any],
    quotes: list[Quote],
    market_sentiment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    sentiment = market_sentiment or {}
    if not quotes:
        return _empty_bundle("没有实时行情数据，系统保持空仓观察", sentiment)

    market_state = str(state.get("state") or "SIDEWAYS").upper()
    if market_state == "DOWNTREND":
        return {
            **_empty_bundle("市场处于下行状态，暂停新增买入推荐", sentiment),
            "signal": "SELL",
            "risk_level": "high",
        }
    if market_state == "NO_DATA":
        return _empty_bundle("行情状态不可用，暂停推荐", sentiment)
    if _sentiment_blocks_new_buys(sentiment):
        return {
            **_empty_bundle(_sentiment_no_buy_reason(sentiment), sentiment),
            "signal": "HOLD",
            "risk_level": "high",
        }

    leader_strength = _leader_strength_map(leader)
    ranked_rows = []
    for quote in quotes:
        strength = leader_strength.get(quote.symbol, _fallback_strength(quote))
        quality = evaluate_quality(quote)
        tradability = evaluate_tradability(quote)
        score = _rank_score(state, sentiment, strength, quality, tradability)
        action = _action_for(market_state, sentiment, strength, score, quality, tradability)
        ranked_rows.append(
            {
                "symbol": quote.symbol,
                "name": quote.name,
                "action": action,
                "current_price": round(quote.price, 2),
                "pct_change": round(quote.pct_change, 2),
                "amount_yi": round(quote.amount_yi, 2),
                "volume_ratio": round(quote.volume_ratio, 2),
                "leader_strength": round(strength, 2),
                "sentiment_score": _sentiment_score(sentiment, state),
                "sentiment_status": sentiment.get("sentiment_status", "unknown"),
                "trade_permission": sentiment.get("trade_permission", "BUY_ALLOWED"),
                "quality_score": quality["score"],
                "tradability_score": tradability["score"],
                "rank_score": round(score, 2),
                "confidence": round(score / 100, 4),
                "position": _position_for(action, score, sentiment),
                "buy_range": {
                    "low": tradability["buy_range_low"],
                    "high": tradability["buy_range_high"],
                },
                "max_buy_price": tradability["max_buy_price"],
                "stop_loss": tradability["stop_loss"],
                "buy_mode": _buy_mode(action, tradability),
                "can_buy": tradability["can_buy"],
                "is_limit_up": tradability["is_limit_up"],
                "near_limit_up": tradability["near_limit_up"],
                "limit_up_price": tradability["limit_up_price"],
                "quality": quality,
                "tradability": tradability,
                "reasoning": _reasoning(action, state, sentiment, strength, quality, tradability),
                "risk_flags": _risk_flags(quality, tradability, sentiment),
            }
        )

    ranked_rows.sort(key=lambda item: item["rank_score"], reverse=True)
    max_push_stocks = param_int("MAX_PUSH_STOCKS", settings.max_push_stocks)
    recommendations = [item for item in ranked_rows if item["action"] == "BUY"][:max_push_stocks]
    watchlist = [item for item in ranked_rows if item["action"] == "WATCH"][:max_push_stocks]
    filtered_count = sum(1 for item in ranked_rows if item["action"] == "FILTERED")

    signal = "BUY" if recommendations else "HOLD"
    position = min(sum(item["position"] for item in recommendations), settings.max_position_weight)
    return {
        "output_type": "v1_4_ranked_recommendations",
        "signal": signal,
        "position": round(position, 4),
        "risk_level": "medium" if recommendations else "normal",
        "recommendations": recommendations,
        "watchlist": watchlist,
        "candidate_count": len(ranked_rows),
        "recommendation_count": len(recommendations),
        "filtered_count": filtered_count,
        "market_sentiment": sentiment,
        "no_recommendation_reason": (
            None if recommendations else _no_recommendation_reason(market_state, sentiment, watchlist)
        ),
        "selection_logic": (
            "先看市场情绪能否允许出手，再过滤涨停/接近涨停/ST/低流动性，"
            "最后按市场状态、情绪、龙头强度、可买性、基础质地和风险综合排序"
        ),
    }


class RankingEngine:
    def build(
        self,
        state: dict[str, Any],
        leader: dict[str, Any],
        quotes: list[Quote],
        market_sentiment: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return build_recommendation_bundle(state, leader, quotes, market_sentiment)


def merge_signal_with_recommendations(signal: dict[str, Any], bundle: dict[str, Any]) -> dict[str, Any]:
    merged = dict(signal)
    merged["signal"] = bundle.get("signal", merged.get("signal", "HOLD"))
    merged["position"] = bundle.get("position", merged.get("position", 0.0))
    merged["risk_level"] = bundle.get("risk_level", merged.get("risk_level", "normal"))
    merged["recommendations"] = bundle.get("recommendations", [])
    merged["watchlist"] = bundle.get("watchlist", [])
    merged["candidate_count"] = bundle.get("candidate_count", 0)
    merged["recommendation_count"] = bundle.get("recommendation_count", 0)
    merged["filtered_count"] = bundle.get("filtered_count", 0)
    merged["market_sentiment"] = bundle.get("market_sentiment", merged.get("market_sentiment", {}))
    merged["no_recommendation_reason"] = bundle.get("no_recommendation_reason")
    merged["selection_logic"] = bundle.get("selection_logic")
    return merged


def _empty_bundle(reason: str, market_sentiment: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "output_type": "v1_4_ranked_recommendations",
        "signal": "HOLD",
        "position": 0.0,
        "risk_level": "high",
        "recommendations": [],
        "watchlist": [],
        "candidate_count": 0,
        "recommendation_count": 0,
        "filtered_count": 0,
        "market_sentiment": market_sentiment or {},
        "no_recommendation_reason": reason,
        "selection_logic": "行情不可用或市场状态不适合新增买入",
    }


def _leader_strength_map(leader: dict[str, Any]) -> dict[str, float]:
    mapping: dict[str, float] = {}
    for item in leader.get("candidates") or []:
        symbol = item.get("symbol")
        if symbol:
            mapping[str(symbol)] = float(item.get("strength") or 0)
    if leader.get("stock"):
        mapping[str(leader["stock"])] = float(leader.get("strength") or mapping.get(str(leader["stock"]), 0))
    return mapping


def _fallback_strength(quote: Quote) -> float:
    momentum = max(min(quote.pct_change, 10), -10) * 4
    liquidity = min(quote.amount_yi, 20) * 1.5
    volume = min(quote.volume_ratio, 3) * 8
    return max(0.0, min(100.0, 45 + momentum + liquidity + volume))


def _rank_score(
    state: dict[str, Any],
    market_sentiment: dict[str, Any],
    strength: float,
    quality: dict[str, Any],
    tradability: dict[str, Any],
) -> float:
    market_score = _market_score(state)
    sentiment_score = _sentiment_score(market_sentiment, state)
    risk_penalty = 0.0
    if not quality["passed"]:
        risk_penalty += 12.0
    if not tradability["can_buy"]:
        risk_penalty += 18.0
    if str(market_sentiment.get("trade_permission") or "").upper() == "LIGHT_ONLY":
        risk_penalty += 4.0
    if str(market_sentiment.get("trade_permission") or "").upper() == "NO_BUY":
        risk_penalty += 30.0
    if float(market_sentiment.get("panic_score") or 0) >= 55:
        risk_penalty += 10.0
    return max(
        0.0,
        min(
            100.0,
            market_score * 0.15
            + sentiment_score * 0.25
            + strength * 0.22
            + float(tradability["score"]) * 0.22
            + float(quality["score"]) * 0.16
            - risk_penalty,
        ),
    )


def _market_score(state: dict[str, Any]) -> float:
    market_state = str(state.get("state") or "SIDEWAYS").upper()
    sentiment = float(state.get("sentiment") or 50)
    if market_state == "UPTREND":
        return min(100.0, sentiment + 12.0)
    if market_state == "SIDEWAYS":
        return min(72.0, sentiment)
    return max(0.0, sentiment * 0.45)


def _action_for(
    market_state: str,
    market_sentiment: dict[str, Any],
    strength: float,
    score: float,
    quality: dict[str, Any],
    tradability: dict[str, Any],
) -> str:
    threshold = param_float("CONFIDENCE_THRESHOLD", settings.confidence_threshold) * 100
    sentiment_score = _sentiment_score(market_sentiment, {})
    panic_score = float(market_sentiment.get("panic_score") or 0)
    panic_threshold = param_float("SENTIMENT_PANIC_THRESHOLD", settings.sentiment_panic_threshold)
    min_buy_score = param_float("SENTIMENT_MIN_BUY_SCORE", settings.sentiment_min_buy_score)
    trade_permission = str(market_sentiment.get("trade_permission") or "BUY_ALLOWED").upper()
    if trade_permission == "NO_BUY" or panic_score >= panic_threshold:
        return "WATCH" if score >= 65 and quality["passed"] and not tradability["is_limit_up"] else "FILTERED"

    if trade_permission == "LIGHT_ONLY":
        threshold = max(threshold, 74.0)
        min_strength = 68.0
        min_sentiment = min_buy_score + 2
    else:
        threshold = max(threshold, 72.0)
        min_strength = 65.0
        min_sentiment = min_buy_score

    if (
        market_state == "UPTREND"
        and sentiment_score >= min_sentiment
        and panic_score < 55
        and strength >= min_strength
        and score >= threshold
        and quality["passed"]
        and tradability["can_buy"]
    ):
        return "BUY"
    if score >= 62 and quality["passed"] and not tradability["is_limit_up"]:
        return "WATCH"
    return "FILTERED"


def _position_for(action: str, score: float, market_sentiment: dict[str, Any]) -> float:
    if action != "BUY":
        return 0.0
    scaled = 0.04 + max(0.0, score - 72.0) / 100 * 0.18
    permission = str(market_sentiment.get("trade_permission") or "BUY_ALLOWED").upper()
    coverage_level = str(market_sentiment.get("coverage_level") or "").lower()
    multiplier = 1.0
    if permission == "LIGHT_ONLY":
        multiplier *= 0.5
    if coverage_level == "low":
        multiplier *= 0.7
    return round(min(settings.max_position_weight, scaled * multiplier), 4)


def _buy_mode(action: str, tradability: dict[str, Any]) -> str:
    if action != "BUY":
        return "仅观察，不追价"
    return (
        "当前价落入区间可分批挂单；超过买入上沿不追，等回落或下一轮刷新"
        if tradability["can_buy"]
        else "不可买入，等待重新进入可成交区"
    )


def _reasoning(
    action: str,
    state: dict[str, Any],
    market_sentiment: dict[str, Any],
    strength: float,
    quality: dict[str, Any],
    tradability: dict[str, Any],
) -> str:
    sentiment_score = _sentiment_score(market_sentiment, state)
    trade_permission = market_sentiment.get("trade_permission", "BUY_ALLOWED")
    if action == "BUY":
        return (
            f"市场{state.get('state')}，龙头强度{strength:.0f}，"
            f"情绪{sentiment_score:.0f}/{trade_permission}，"
            f"质地{quality['score']:.0f}，可买性{tradability['score']:.0f}，满足小仓试错条件"
        )
    if action == "WATCH":
        return "综合评分尚可，但市场情绪、买点或成交条件尚未完全确认，进入观察池"
    return "未通过可买性、基础质地或市场时机过滤"


def _risk_flags(
    quality: dict[str, Any],
    tradability: dict[str, Any],
    market_sentiment: dict[str, Any],
) -> list[str]:
    flags: list[str] = []
    if not quality["passed"]:
        flags.append("quality_filtered")
    if not tradability["can_buy"]:
        flags.append("tradability_filtered")
    if tradability["is_limit_up"]:
        flags.append("limit_up")
    elif tradability["near_limit_up"]:
        flags.append("near_limit_up")
    for flag in market_sentiment.get("flags") or []:
        if flag in {"low_sentiment_coverage", "panic_pressure", "sentiment_no_buy", "sentiment_light_only"}:
            flags.append(flag)
    return flags


def _no_recommendation_reason(
    market_state: str,
    market_sentiment: dict[str, Any],
    watchlist: list[dict[str, Any]],
) -> str:
    trade_permission = str(market_sentiment.get("trade_permission") or "").upper()
    if trade_permission == "NO_BUY":
        return _sentiment_no_buy_reason(market_sentiment)
    if trade_permission == "LIGHT_ONLY":
        return "市场情绪只允许轻仓观察，当前标的尚未达到更高买入门槛"
    if market_state != "UPTREND":
        return f"市场状态为{market_state}，系统只观察不新增买入"
    if watchlist:
        return "有观察标的，但尚未同时满足时机、质地、流动性和可买价格"
    return "候选池没有通过涨停过滤、质地过滤和成交额过滤的标的"


def _sentiment_score(market_sentiment: dict[str, Any], state: dict[str, Any]) -> float:
    try:
        return float(market_sentiment.get("sentiment_score") or state.get("sentiment") or 50)
    except (TypeError, ValueError):
        return 50.0


def _sentiment_blocks_new_buys(market_sentiment: dict[str, Any]) -> bool:
    permission = str(market_sentiment.get("trade_permission") or "").upper()
    panic_score = float(market_sentiment.get("panic_score") or 0)
    panic_threshold = param_float("SENTIMENT_PANIC_THRESHOLD", settings.sentiment_panic_threshold)
    return permission == "NO_BUY" or panic_score >= panic_threshold


def _sentiment_no_buy_reason(market_sentiment: dict[str, Any]) -> str:
    status = market_sentiment.get("sentiment_status", "unknown")
    score = _sentiment_score(market_sentiment, {})
    panic = float(market_sentiment.get("panic_score") or 0)
    flags = ",".join(market_sentiment.get("flags") or [])
    return f"市场情绪为{status}，情绪分{score:.0f}，恐慌分{panic:.0f}，暂停新增买入；标记：{flags or 'none'}"
